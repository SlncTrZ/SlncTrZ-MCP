# SlncTrZ-MCP — editable introduction

Vietnamese captions, silent, 60 seconds, portrait 9:16, native 2160×3840 at 60 FPS.
The animated UI is illustrative, rather than an installed-client screen recording.
Read STORYBOARD.md for the six scenes and claim boundaries.

## Edit and render

Edit intro.html. Fonts and their license are in fonts/.
Requires Node 22.13+ (Node 24 recommended), Chromium with its sandbox enabled,
FFmpeg with libx264, and ffprobe. No remote image or font downloads are needed.

```sh
node render.mjs --preflight
node render.mjs intro.html new-preview --preview
node render.mjs intro.html new-full-output
```

Every output directory must be new. The original renderer is included unchanged.
Inspect the contact sheet and full-resolution frames before publishing.

## Delivered render

All 3,600 native frames were captured. The renderer passed 36 samples, reverse seeking,
delayed-repeat determinism, font/readiness, and frame/layout checks. The delivered
sample hashes also match the corresponding full captured frames.

The renderer's first medium-preset encoding hit its five-minute subprocess timeout after
capture had completed. The retained PNG frames were then encoded separately through the
managed Runner with the renderer's normal video settings: libx264, medium, CRF 18,
yuv420p, 60 FPS and faststart. That encode completed in about 284 seconds. report.json
documents the actual command, source/assets/renderer/video hashes and ffprobe frame count.
Full-capture mean/p95 timings were not emitted after the original renderer failure and are
explicitly absent rather than inferred.

For the same recovery after an interrupted encoding, use a new output filename:

```sh
ffmpeg -v error -nostdin -n -framerate 60 -start_number 0 \
  -i new-full-output/frames/%06d.png -frames:v 3600 -an \
  -c:v libx264 -threads 2 -preset medium -crf 18 \
  -pix_fmt yuv420p -r 60 -movflags +faststart video-recovered.mp4
```

The source zip omits the large full-frame sequence and synthetic OAuth credentials.
The MP4 is available separately from the project README.
