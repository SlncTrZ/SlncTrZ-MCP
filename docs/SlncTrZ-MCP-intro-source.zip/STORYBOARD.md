# SlncTrZ-MCP — Video giới thiệu

Bản dọc 9:16, 60 giây, 2160×3840/60 FPS. Tiếng Việt, không lời đọc. Chuyển động minh họa; không phải bản ghi thao tác của client.

| Giây | Câu hỏi | Thông điệp / hình | Chuyển động |
| --- | --- | --- | --- |
| 0–8 | Là gì? | AI trò chuyện. Máy của bạn. Công việc thật. Một gateway tự host để AI làm việc với file, lệnh và dự án của bạn. | Mở ngay tiêu đề, giữ trạng thái dễ đọc |
| 8–18 | Có gì? | Từ Chat. Đến file thật. Đọc code. Sửa file. Chạy lệnh. Ngay trong cuộc trò chuyện. | Crossfade 0,7 giây, giữ trạng thái dễ đọc |
| 18–28 | Có gì? | Ngữ cảnh đúng. Skills khi cần. Hướng dẫn, skills custom và tác vụ. Mở rộng theo cách bạn làm việc. | Crossfade 0,7 giây, giữ trạng thái dễ đọc |
| 28–39 | Có gì? | Nhiều MCP. Một contract. Agent dùng gateway-only. OAuth một lần, dùng đến khi thu hồi. | Crossfade 0,7 giây, giữ trạng thái dễ đọc |
| 39–49 | Có gì? | Cùng phản biện. Cùng làm việc. Các agent trao đổi và nhận việc. Phối hợp cả với model nhỏ. | Crossfade 0,7 giây, giữ trạng thái dễ đọc |
| 49–60 | Giúp ai, tốt ở đâu? | Người dùng AI. Lập trình viên. Người dùng MCP. Bạn chọn quyền. Bạn giữ kiểm soát. Bắt đầu tại GitHub / SlncTrZ-MCP. | Crossfade 0,7 giây, giữ trạng thái dễ đọc |

Source dùng window.video.render(t), local fonts và thời gian tuyệt đối. Dữ liệu/luồng minh họa được ghi trên scene Debate. Trải nghiệm Free/Plus và % Work thuộc lời chứng của tác giả; không phải lời hứa quota chung. OAuth Gateway-only mới là source chưa phát hành; README và guide ghi trạng thái này.

Tái tạo: mở thư mục source, có Node22.13+, Chromium sandbox, ffmpeg và ffprobe; chạy `node render.mjs intro.html new-output`. Không tái sử dụng thư mục output đã có. Font license nằm trong fonts/LICENSE.txt. Báo cáo render lưu hash source/fonts/helper/video, môi trường, Latency, ffprobe và kiểm tra seek.
